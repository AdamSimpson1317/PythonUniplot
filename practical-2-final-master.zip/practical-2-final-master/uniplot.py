from uniplot.cli import cli

if __name__  == "__main__":
    LOC=input("Input Filename:")
    cli(LOC)
